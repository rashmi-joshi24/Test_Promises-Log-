package PromisesLog.Login;

import java.io.IOException;

import org.testng.annotations.Test;

import utilities.base;

public class LoginFunctionality extends base{

	@Test
	public void abc() throws IOException, InterruptedException
	{
		Thread.sleep(5000);
		Login_Error_Page atp = new Login_Error_Page(driver);
		atp.Login("sanjeetk@clariontechnologies.co.in","clarion");
		
	
	}
}
