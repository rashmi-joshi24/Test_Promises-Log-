package PromisesLog.Login;

import java.io.IOException;

import org.testng.annotations.Test;

import utilities.base;

public class Verify_Promise_added extends base{

	@Test
	public void abc() throws IOException, InterruptedException
	{
		Thread.sleep(5000);
		Add_Promisepage atp = new Add_Promisepage(driver);
		atp.Log_Promise();
		
	
	}

	
}
