package PromisesLog.Login;

import java.io.IOException;

import org.testng.annotations.Test;

import utilities.base;

public class Logout_test extends base{

	@Test
	public void abc() throws IOException, InterruptedException
	{
		Thread.sleep(5000);
		Log_out_Page atp = new Log_out_Page(driver);
		atp.Log_out();
		
	
	}

	
}
