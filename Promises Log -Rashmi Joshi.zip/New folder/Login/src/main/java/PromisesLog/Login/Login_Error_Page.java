package PromisesLog.Login;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.CaptureScreenshot;

public class Login_Error_Page {
	
	public WebDriver driver;
	
	public Login_Error_Page(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(name="txtUsername")
	WebElement username;
	
	@FindBy(xpath="//input[@name='txtPassword']")
	WebElement password;
	
	
	@FindBy(className="button_white")
	WebElement Login;
	
	@FindBy(className="font")
	WebElement error_msg;
	
		public void Login(String un, String pw) {
		// TDO Auto-generated method stub
		username.sendKeys(un);
		password.sendKeys(pw);
		Login.click();
			
	    String actualusername ="sanjeetk@clariontechnologies.co.in";
            String expectedusername =username.getAttribute("value");
            String actualpwd = " clarion";
             String expectedpwd = password.getAttribute("value");

            if (actualusername.equalsIgnoreCase(expectedusername) && actualpwd.equalsIgnoreCase(expectedpwd)  ) {
                System.out.println("Test passed");
               boolean status = true;
               String message=error_msg.getAttribute("value");
               System.out.println(message);
              } else {
                System.out.println("Test failed"); 
 
	} 
		}
		}	
