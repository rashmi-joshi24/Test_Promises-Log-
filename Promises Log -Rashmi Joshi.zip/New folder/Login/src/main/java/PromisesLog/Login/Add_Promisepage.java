package PromisesLog.Login;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utilities.CaptureScreenshot;

public class Add_Promisepage {
	
	public WebDriver driver;
	
	public Add_Promisepage(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(linkText="Log Promise")
	WebElement Log_Promise;
	
	@FindBy(name="cboEmp")
	WebElement Promise_form;
	
	
	@FindBy(id="txtPromise")
	WebElement Promise;
	
	@FindBy(xpath="//input[@id='btnSubmit']")
	WebElement btnLog_promise;
	
		
public void Log_Promise()
{
	Log_Promise.click();
	Select s = new Select(Promise_form);	
	s.selectByVisibleText("Sonali test");
	Promise.sendKeys("Test for Testing Profile");
	btnLog_promise.click();
	
}

}