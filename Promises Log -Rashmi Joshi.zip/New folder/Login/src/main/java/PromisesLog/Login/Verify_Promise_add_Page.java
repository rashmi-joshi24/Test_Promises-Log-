package PromisesLog.Login;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utilities.CaptureScreenshot;

public class Verify_Promise_add_Page {
	
	public WebDriver driver;
	
	public Verify_Promise_add_Page(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	
	@FindBy(name="cboEmp")
	WebElement Promise_form;
	
	
	@FindBy(css="body.body_default:nth-child(2) table:nth-child(1) tbody:nth-child(1) tr:nth-child(3) td:nth-child(1) > input.button_white:nth-child(1)")
	WebElement btn_search;
	
	
		
public void Search_Promise()
{
	
	Select s = new Select(Promise_form);	
	s.selectByVisibleText("Sonali test");
	btn_search.click();
	
}

}